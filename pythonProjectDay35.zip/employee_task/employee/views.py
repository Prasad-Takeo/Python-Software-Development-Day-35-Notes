from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response

from django.contrib.auth.models import User
from employee.models import Employee, EmployeeTask, EmployeeData
from employee.serializers import EmployeeSerializer, EmployeeTaskSerializer, EmployeeDataSerializer, UserSerializer

from rest_framework import permissions
from employee.permissions import IsCreatorOrReadOnly


# Create your views here.

# @api_view(['GET','POST'])
# def employee_list(request):
#     """
#     list all employees
#     :return:
#     """
#     if request.method == 'GET':
#         employees = Employee.objects.all()
#         serializer = EmployeeSerializer(employees,many=True)
#         return Response(serializer.data)
#
#     if request.method == 'POST':
#         serializer = EmployeeSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data,status = status.HTTP_201_CREATED)
#         return Response(serializer.errors,status = status.HTTP_400_BAD_REQUEST)

class EmployeeList(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self,request):
        employees = Employee.objects.all()
        serializer = EmployeeSerializer(employees,many=True)
        return Response(serializer.data)

    def post(self,request):
        serializer = EmployeeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(creator = request.user)
            return Response(serializer.data,status = status.HTTP_201_CREATED)
        return Response(serializer.errors,status = status.HTTP_400_BAD_REQUEST)

class EmployeeDetail(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsCreatorOrReadOnly]

    def get_object(self,pk):
        try:
            return Employee.objects.get(pk=pk)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def get(self,request,pk):
        employee = self.get_object(pk)
        serializer = EmployeeSerializer(employee)
        return Response(serializer.data)

    def put(self,request,pk):
        employee = self.get_object(pk)
        self.check_object_permissions(request,employee)
        serializer = EmployeeSerializer(employee, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self,request,pk):
        employee = self.get_object(pk)
        self.check_object_permissions(request, employee)
        employee.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

# @api_view(['GET','PUT','DELETE'])
# @permission_classes((permissions.IsAuthenticatedOrReadOnly,IsCreatorOrReadOnly,))
# def employee_details(request,pk):
#     try:
#         employee =
#     except:
#
#
#     if request.method == "GET":
#
#
#     elif request.method == "PUT":
#
#
#     elif request.method == "DELETE":



@api_view(['GET','POST'])
def employee_task_list(request):
    if request.method == 'GET':
        employeetasks = EmployeeTask.objects.all()
        serializer = EmployeeTaskSerializer(employeetasks,many=True)
        return Response(serializer.data)


class EmployeeDataList(APIView):
    def get(self,request):
        employeedata = EmployeeData.objects.all()
        serializer = EmployeeDataSerializer(employeedata, many=True)
        return Response(serializer.data)


class UserList(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class UserDetail(generics.RetrieveAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
