from django.urls import path, include
from rest_framework.urlpatterns import format_suffix_patterns
from employee import views

urlpatterns = [
    path('employees/',views.EmployeeList.as_view()),
    path('employees/<int:pk>',views.EmployeeDetail.as_view()),
    path('employees-task/',views.employee_task_list),
    path('employees-data/',views.EmployeeDataList.as_view()),
    path('users/',views.UserList.as_view()),
    path('users/<int:pk>',views.UserDetail.as_view()),
    path('api-auth/',include('rest_framework.urls'))
]

urlpatterns += format_suffix_patterns(urlpatterns)